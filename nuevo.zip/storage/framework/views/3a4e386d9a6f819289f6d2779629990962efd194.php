<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Gestion de DB')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="">

        <?php if(Session::has("success1")): ?>
        <div class="bg-green-100 border-l-4 border-green-500 text-green-700 p-4" role="alert">
            <p class="font-bold">Success</p>
            <p><?php echo e(session("success1")); ?></p>

        </div>
        <?php endif; ?>

        <?php if(Session::has("success3")): ?>
        <div class="bg-green-100 border-l-4 border-green-500 text-green-700 p-4" role="alert">
            <p class="font-bold">Success</p>
            <p><?php echo e(session("success3")); ?></p>
        </div>
        <?php endif; ?>

        <?php if(Session::has("successAll")): ?>
        <div class="bg-green-100 border-l-4 border-green-500 text-green-700 p-4" role="alert">
            <p class="font-bold">Success</p>
            <p><?php echo e(session("successAll")); ?></p>

        </div>
        <?php endif; ?>


        <?php if(Session::has("danger")): ?>
        <div class="bg-red-100 border-l-4 border-red-500 text-red-700 p-4" role="alert">
            <p class="font-bold">Error</p>
            <p><?php echo e(session("danger")); ?></p>

        </div>
        <?php endif; ?>

        <div class="max-w-4xl mx-auto sm:px-6 lg:px-8">


            <div class="max-w-5xl mx-auto my-4 bg-white rounded overflow-hidden shadow-md">



                <form method="POST" action="<?php echo e(url('/db')); ?>" enctype="multipart/form-data" class="mx-4 px-4 py-4 my-4">
                    <?php echo csrf_field(); ?>
                    <div>
                        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.label','data' => ['class' => 'mb-2','for' => 'fv1Upload','value' => ''.e(__('Cargar Fv1')).'']]); ?>
<?php $component->withName('jet-label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'mb-2','for' => 'fv1Upload','value' => ''.e(__('Cargar Fv1')).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                        <div class="flex justify-center">
                            <div class="mb-3 w-full flex">

                                <input name="fv1Upload" id="fv1Upload" class="form-control
                                block
                                w-full
                                px-3
                                py-1.5
                                text-base
                                font-normal
                                text-gray-700
                                bg-white bg-clip-padding
                                border border-solid border-gray-300
                                rounded
                                transition
                                ease-in-out
                                file:p-2
                                file:mx-2
                        
                                file:shadow-sm
                                file:bg-transparent
                               
                                file:border-gray-300
                            
                                
                                file:text-gray-700
                                file:uppercase
                                file:rounded
                                file:border
                                file:border-solid
                                file:border-gray-300
                                file:font-semibold
                                file:text-xs





                                focus:text-gray-700 focus:bg-white focus:border-blue-600 focus:outline-none" type="file" id="formFile"  autofocus autocomplete="name">
                              
                            </div>
                        </div>

                        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.label','data' => ['class' => 'mb-2','for' => 'fv3Upload','value' => ''.e(__('Cargar Fv3')).'']]); ?>
<?php $component->withName('jet-label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'mb-2','for' => 'fv3Upload','value' => ''.e(__('Cargar Fv3')).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>

                        <div class="flex justify-center">
                            <div class="mb-3 w-full flex">
                                <input name="fv3Upload" id="fv3Upload" class="form-control
                                block
                                w-full
                                px-3
                                py-1.5
                                text-base
                                font-normal
                                text-gray-700
                                bg-white bg-clip-padding
                                border border-solid border-gray-300
                                rounded
                                transition
                                ease-in-out
                                file:p-2
                                file:mx-2
                        
                                file:shadow-sm
                                file:bg-transparent
                               
                                file:border-gray-300
                            
                                
                                file:text-gray-700
                                file:uppercase
                                file:rounded
                                file:border
                                file:border-solid
                                file:border-gray-300
                                file:font-semibold
                                file:text-xs
                                focus:text-gray-700 focus:bg-white focus:border-blue-600 focus:outline-none" type="file" id="formFile"  autofocus autocomplete="name">
                               
                            </div>
                        </div>
                    </div>
                    <div class="flex items-center justify-end mt-4">
                        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.button','data' => ['class' => 'ml-4']]); ?>
<?php $component->withName('jet-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'ml-4']); ?>
                            <?php echo e(__('Subir Archivos')); ?>

                         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                    </div>
                </form>

            </div>
        </div>



        <div class="max-w-4xl mx-auto sm:px-6 lg:px-8">

            <div class="max-w-5xl mx-auto my-4 bg-white rounded overflow-hidden shadow-lg">







                <div class="overflow-auto rounded-lg shadow">
                    <table class="w-full mx-auto shadow-xl ">
                        <thead class="bg-white-50">
                            <tr class="border-b border-gray-600">
                                <td class="p-3 text-sm font-bold text-gray-900 text-center">ACCION 🛠️</td>
                                <td class="p-3 text-sm font-bold text-gray-900 text-center">DESCRIPCION 📓</td>
                                <td class="p-3 text-sm font-bold text-gray-900 text-center">ELIMINAR ❌</td>
                            </tr>


                            <form method="GET" action="<?php echo e(url('/deleteFv1')); ?>" class="mx-4 px-4 py-4 my-4">
                                <?php echo csrf_field(); ?>

                                <tr class=" border-b ">
                                    <td class="p-3 text-sm font-bold text-gray-900 text-center ">Eliminar fv1</td>
                                    <td class="p-3 text-sm font-semibold text-gray-900 text-center">Esta accion limpia los registros de la tabla ferre1 de la base de datos.</td>
                                    <td class="p-3 text-sm font-bold text-gray-900 text-center">
                                        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.danger-button','data' => ['class' => 'ml-4','onclick' => 'return confirm(\'Esta seguro de realizar esta accion?\');','type' => 'submit']]); ?>
<?php $component->withName('jet-danger-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'ml-4','onclick' => 'return confirm(\'Esta seguro de realizar esta accion?\');','type' => 'submit']); ?>
                                            <?php echo e(__('Borrar')); ?>

                                         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                                    </td>
                                    </td>


                                </tr>
                            </form>
                            <form method="GET" action="<?php echo e(url('/deleteFv3')); ?>" class="mx-4 px-4 py-4 my-4">
                                <?php echo csrf_field(); ?>
                                <tr class=" border-b ">
                                    <td class="p-3 text-sm font-bold text-gray-900 text-center">Eliminar fv3</td>
                                    <td class="p-3 text-sm font-semibold text-gray-900 text-center">Esta accion limpia los registros de la tabla ferre3 de la base de datos.</td>
                                    <td class="p-3 text-sm font-bold text-gray-900 text-center">
                                        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.danger-button','data' => ['class' => 'ml-4','onclick' => 'return confirm(\'Esta seguro de realizar esta accion?\');','type' => 'submit']]); ?>
<?php $component->withName('jet-danger-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'ml-4','onclick' => 'return confirm(\'Esta seguro de realizar esta accion?\');','type' => 'submit']); ?>
                                            <?php echo e(__('Borrar')); ?>

                                         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                                    </td>
                                    </td>
                                </tr>
                            </form>
                            <form method="GET" action="<?php echo e(url('/deleteAll')); ?>" class="mx-4 px-4 py-4 my-4">
                                <?php echo csrf_field(); ?>
                                <tr class=" border-b ">
                                    <td class="p-3 text-sm font-bold text-gray-900 text-center">Eliminar Todos</td>
                                    <td class="p-3 text-sm font-semibold text-gray-900 text-center">Esta accion limpia los registros de todas las tablas ferre1 y ferre3 de la base de datos.</td>
                                    <td class="p-3 text-sm font-bold text-gray-900 text-center">
                                        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.danger-button','data' => ['class' => 'ml-4','onclick' => 'return confirm(\'Esta seguro de realizar esta accion?\');','type' => 'submit']]); ?>
<?php $component->withName('jet-danger-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'ml-4','onclick' => 'return confirm(\'Esta seguro de realizar esta accion?\');','type' => 'submit']); ?>
                                            <?php echo e(__('Borrar')); ?>

                                         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                                    </td>
                                    </td>
                                </tr>
                            </form>

                        </thead>
                    </table>
                </div>

            </div>
        </div>

    </div>







 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?><?php /**PATH /home/u324364587/domains/ferrevente.net/public_html/resources/views/database/ferredata.blade.php ENDPATH**/ ?>
<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Factores Referenciales')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="">
        
                    <?php if(Session::has("success")): ?>
                    <div class="bg-green-100 border-l-4 border-green-500 text-green-700 p-4" role="alert">
                        <p class="font-bold">Success</p>
                        <p>El <?php echo e(session("success")); ?></p>
        
                    </div>
                    <?php endif; ?>

    






        <div class="container mt-4 mx-auto">
            <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-2 lg:grid-cols-4 mx">
                <?php $__currentLoopData = $factores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $factor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <div class="card m-2 cursor-pointer bg-white border border-gray-400 rounded-lg hover:shadow-md hover:border-opacity-0 transform hover:-translate-y-1 transition-all duration-200">
                    <div class="m-3 ">
                        <h2 class="text-lg mb-2">Factor Referencial
                            <span class="text-sm text-teal-800 font-mono bg-teal-100 inline rounded-full px-2 align-top float-right animate-pulse">Dolar</span>
                        </h2>
                        <p class="font-light font-mono text-sm text-gray-700 hover:text-gray-900 transition-all duration-200 text-center text-7xl"><?php echo e($factor->FactorReferencial . "Bs"); ?></p>

                        <p class="font-light font-mono text-sm text-gray-700 hover:text-gray-900 transition-all duration-200 text-center ">Ultima actualizacion : <?php echo e($factor->updated_at); ?></p>


                        <form action="<?php echo e(url('factor_ref/create')); ?>" method="GET">
                            <?php echo csrf_field(); ?>
                               
                            <button type="submit" class="mt-2 w-full text-white bg-slate-700 rounded mx-auto p-2 text-white-700 hover:bg-slate-500 duration-500">Actualizar</button>
                        </form>

                    </div>
                </div>


                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>





        <br>



        <div class=" mx-auto my-5 ">


        </div>

    </div>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?><?php /**PATH C:\Users\DELL OPTIPLEX\Desktop\nuevo\resources\views/factorReferencial/Index.blade.php ENDPATH**/ ?>
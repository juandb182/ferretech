<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Sede Mañongo')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="">
        <div class="flex py-2 mx-auto w-full">
            <form action="<?php echo e(url('/searchfv3')); ?>" type="get" method="get" class="w-full flex ">
                <input type="search" value="" name="query" placeholder="Realizar busqueda" class="w-full border-gray  mx-2 rounded-lg bg-white px-4 py-2 text-gray-900">
                <div class="inline-block relative">
                    <select name="order" class=" rounded bg-slate-700 px-2 py-2 text-white transition  hover:bg-slate-500 duration-300">
                        <option>Existencia</option>
                        <option value="ASC">Ascendente</option>
                        <option value="DESC">Descendente</option>
                    </select>
                    <div class="pointer-events-none absolute inset-y-0 right-0 flex items-center px-2 text-gray-700">
                       
                    </div>
                </div>
                <button class="rounded mx-2 bg-slate-700 px-4 py-2 text-white transition  hover:bg-slate-500 duration-300" type="submit">Buscar</button>

            </form>
        </div>

        <div class="overflow-auto rounded-lg shadow">
            <table class="w-full mx-auto shadow-xl ">
                <thead class="bg-gray-50">
                    <tr class="border-b border-gray-600">
                        <td class="p-3 text-sm font-bold text-gray-900 text-center">CODIGO #️⃣</td>
                        <td class="p-3 text-sm font-bold text-gray-900 text-center">PRODUCTOS 🏭</td>
                        <td class="p-3 text-sm font-bold text-gray-900 text-center">PRECIO 💲</td>
                        <td class="p-3 text-sm font-bold text-gray-900 text-center">EXISTENCIA 🗳️</td>
                    </tr>


                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class=" border-b ">
                        <td class="p-3 text-sm font-bold text-gray-900 text-center "><?php echo e($product->CODIGO); ?></td>
                        <td class="p-3 text-sm font-semibold text-gray-900"><?php echo e($product->PRODUCTO); ?> </td>
                        <td class="p-3 text-sm font-bold text-gray-900 text-center"><?php echo e(round($product->PRECIO,2) ." "."$"); ?></td>
                        <td class="p-3 text-sm font-bold text-gray-900 text-center"><?php echo e($product->EXISTENCIA); ?></td>


                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </thead>
            </table>
        </div>

        <div class=" mx-auto my-5 ">
            <?php echo e($products->links()); ?>


        </div>

    </div>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?><?php /**PATH /home/u324364587/domains/ferrevente.tech/public_html/resources/views/ferrevente3/fv3.blade.php ENDPATH**/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>

    <h1>Laravel</h1>
    <p>Prueba con plantilla</p>

    <form action="<?php echo e(url('/prueba/buscar')); ?>" type="get" method="GET" >
        <input type="text" name="busqueda" id="">
        <button type="submit">ENVIAR NOMBRE</button>

    </form>

    <?php echo e($nombreDeSamuel = ""); ?>

    <?php if($nombreDeSamuel == null): ?>

    <?php else: ?>
        <?php echo e($nombreDeSamuel); ?>

    <?php endif; ?>

    
</body>
</html><?php /**PATH C:\Users\DELL OPTIPLEX\Documents\app\ferre\resources\views/prueba/prueba.blade.php ENDPATH**/ ?>